# LLVMBerry #

## Build ##
- Requirements
  + [OPAM](http://opam.ocamlpro.com/)
  + [Boost](http://www.boost.org/users/history/version_1_59_0.html) 1.59.0
  + [CMake](https://cmake.org/) 3.3.2+
  + Make
  + Rsync
  + Python 2.7

- Getting External Projects
```
git clone -b release_37 git@github.com:llvm-mirror/llvm.git lib/llvm    // get LLVM 3.7.1
git clone git@github.com:vellvm/vellvm-legacy.git lib/vellvm    // get Vellvm
patch -d lib/llvm -p0 < lib/llvm.patch
patch -d lib/vellvm -p0 < lib/vellvm.patch
```

- `make init` installs OCaml libraries and places the `cereal` symbolic link at the right place in LLVM.

- `make llvm` builds LLVM into `.build/llvm-obj`.

- `make exec-rsync` builds the translation validator `main.native` into `./ocaml`.

- `make proof-rsync` compiles the proof for the verification of the validator.

- `make proof-quick` compiles the proof for the verification of the validator, using `-quick` option of Coq.

- `make test` optimizes a simple example code `./test/hello/hello.ll` to generate validation proofs, and run the validator.

## Compilation & Proof Generation ##

- `make llvm` generates `opt` at `.build/llvm-obj/bin`

- To run `O2` optimization: `opt -O2 src.bc -o tgt.bc`

- To run `instcombine`: `opt -instcombine src.bc -o tgt.bc`

- To generate validation proof only for specific passes when you run `opt -O2`: `opt -O2 src.bc -o tgt.bc -llvmberry-passwhitelist="gvn,instcombine"`

- To generate compact proofs: `opt -instcombine src.bc -o tgt.bc -llvmberry-compactjson`

- Proof computation without generating files (for performance measure): `opt -instcombine src.bc -o tgt.bc -llvmberry-nocommit`

## Translation Validation ##

- `make exec-rsync` generates `main.native` at `./ocaml`

- To run validation
  + `main.native foo.src.bc foo.tgt.bc foo.hint.json`
  + The `Validation succeeded.` message indicates success.
  + The `Validation failed.` message indicates validation failure due to incomplete proofs.
  + The `Set to admitted.` message indicates that the transformation involves some features we do not support yet.
  + The `Not_Supported.` exception happens when either source or target code contains features that are not supported by Vellvm.

- To run validation with detailed information
  + `main.native -d foo.src.bc foo.tgt.bc foo.hint.json`

## Troubleshooting ##
- `No rule to make target 'ocaml_doc'`
```
rm -rf .build/llvm-obj
mkdir -p .build/llvm-obj
cd .build/llvm-obj
cmake ../../lib/llvm
make
make ocaml_doc
```

## References ##

### Implementation of Validator ##
- `./coq/def` contains the Coq development of the translation validator
  + `Nop.v`: about no-op instructions for instruction alignment
  + `Postcond.v`: the implementation of post-invariant computation
  + `Infrules.v`: the semantics of inference rules
  + `Hints.v`: the definition of invariant structure and inference rules
  + `Validator.v`: the main function of validation

- `./ocaml` contains the OCaml development which mainly translates generated proofs into the formats recognizable by the validator, which is extracted from the Coq development.
  + `convertHint.ml`: the proof converter - from compiler-generated proofs to validator-recognizable
  + `propagateHint.ml`: the invariant propagator
  + `main.ml`: the main function of the validator

- `./coq/proof` contains the ongoing work for the verification of the translation validator
  + `SimulationLocal.v`. `Simulation.v`: the definition of simulation relation
  + `SimulationValid.v`: the proof showing that validation implies simulation
  + `Adequacy.v`, `AdequacyLocal.v`: the adequacy proof

## External Projects
- [LLVM](http://llvm.org/) 3.7.1
- [Vellvm](http://www.cis.upenn.edu/~stevez/vellvm/)
- [cereal](http://uscilab.github.io/cereal/) 1.1.2
- [paco](http://plv.mpi-sws.org/paco/) 1.2.8
- [sflib](https://github.com/snu-sf/sflib)
