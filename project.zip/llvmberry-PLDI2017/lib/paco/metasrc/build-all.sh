#!/bin/sh

./build-paco.sh

make

./build-distr.sh
