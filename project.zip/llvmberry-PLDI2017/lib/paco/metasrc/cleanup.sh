#!/bin/sh

make clean
rm -f paco*.v *.pyc *.html coqdoc.css
rm -rf paco
